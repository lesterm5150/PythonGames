using System;
using System.Drawing;
usign System.Drawing.Drawing2D;
 
namespace TetrisGame
{
    /// <summary>
    /// Layout of the game area. Divided into 10x10 blocks within a rows x cols array
    /// </summary>
    public class GameGrid
    {
        private Rectangle[][] rectangleGameGrid;
        private SolidBrush[][] gameGridBrushes;
        private SolidBrush[] theBrushColors;
 
        public GameGrid(int gameGridRows, int gameGridColumns)
        {
            rectangleGameGrid = new Rectangle [gameGridRows][];
            gameGridBrushes = new SolidBrush[gameGridRows][];
            theBrushColors    = new SolidBrush[5];
 
            // create the GameGrid array and GameGridBrushes array
            for (int i=0;i<gameGridRows;i++)
            {
                rectangleGameGrid[i] = new Rectangle[gameGridColumns];
                gameGridBrushes[i] = new SolidBrush[gameGridColumns];
            }
            // create theBrushColors array
            theBrushColors[0] = new SolidBrush(Color.Blue);
            theBrushColors[1] = new SolidBrush(Color.Red);
            theBrushColors[2] = new SolidBrush(Color.Green);
            theBrushColors[3] = new SolidBrush(Color.Yellow);
            theBrushColors[4] = new SolidBrush(Color.Brown);
        }
        public Rectangle[][] GetGameGrid()
        {
            return rectangleGameGrid;
        }
        public SolidBrush[][] GetGameGridBrushes()
        {
            return gameGridBrushes;
        }
        public SolidBrush[] GetShapeColors()
        {
            return theBrushColors;
        }
        public bool IsGridLocationEmpty(int rowNumber, int colNumber)
        {
            if (rectangleGameGrid[rowNumber][colNumber].IsEmpty)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void SetShapeLocation(int rowNumber, int colNumber, Rectangle square, int shapeType)
        {
            rectangleGameGrid[rowNumber][colNumber] = square;
            setShapeColorLocation(rowNumber, colNumber, shapeType);
        }
        public void setShapeColorLocation(int rowNumber, int colNumber, int shapeType)
        {
            gameGridBrushes[rowNumber][colNumber] = theBrushColors[shapeType-1];
        }
 
        public void DropRowsDown(int rowNumber, int colNumber)
        {
            if (!IsGridLocationEmpty(rowNumber-1, colNumber))
            {
                rectangleGameGrid[rowNumber][colNumber] = new Rectangle(rectangleGameGrid[rowNumber-1][colNumber].X,
                    rectangleGameGrid[rowNumber-1][colNumber].Y+10,10,10);
                gameGridBrushes[rowNumber][colNumber] = gameGridBrushes[rowNumber-1][colNumber];
            }
            else
            {
                rectangleGameGrid[rowNumber][colNumber] = rectangleGameGrid[rowNumber-1][colNumber];
            }
        }
        public void SetTopRow()
        {
            rectangleGameGrid[0] = new Rectangle[rectangleGameGrid[1].Length];
        }
    }
}