using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WiimoteLib;
using System.IO;//for use in creating a menu item that will open the readme.txt file.
using System.Media;
using System.Runtime.InteropServices; // DllImport()
namespace TetrisGame
{
    public class Form1 : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Panel drawingAreaCanvas;
        private System.ComponentModel.IContainer components;
 
        //these are the initializers for the wii remote.
        Wiimote wm;
        Timer timer;
        bool aBtnClicked;
        //sound controlls for buttons clicked.
        SoundPlayer soundEndGame = new SoundPlayer(@"soundEndGame.wav");
        SoundPlayer soundItemDropped = new SoundPlayer(@"soundItemDropped.wav");
        SoundPlayer soundMoveShape = new SoundPlayer(@"soundMoveShape.wav");
        SoundPlayer soundRotateShape = new SoundPlayer(@"soundRotateShape.wav");
 
 
        int drawingAreaWidth;
        int drawingAreaHeight;
 
        Rectangle rectangle;
        Rectangle[] rectangleShape;
        Shape aShape;
        private SolidBrush[][] arrayBrushes = new SolidBrush[30][];
        private SolidBrush[] brushColors = new SolidBrush[5];
        private int shapeType;
        private int nextShapeType;
        private Random randomShapeType = new Random();
        private bool isRowFull;
        private bool isDropped = false;
 
 
        // make a reference to our GameGrid
        private GameGrid gameGrid;
        private int numberOfRows;
        private int numberOfCols;
        private SolidBrush[][] gameGridBrushes;
        private SolidBrush[] theBrushColors;
        private System.Windows.Forms.Timer GameTimer;
        private Rectangle[][] rectangleGameGrid;
        private int dropRate;
        private int gameSpeed;
        private int bonusHeight;
        private Screen mainScreen;
        private Screen startScreen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblScore;
        private int bonusStep;
        private long score;
        private int level;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRows;
        private int levelRowsCompleted;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private int totalRowsCompleted;
        private bool isGameOver;
        private System.Windows.Forms.Label label4;
        private bool isGamePaused;
        private bool dropBtnPressed=false;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuFile;
        private ToolStripMenuItem menuNewGame;
        private ToolStripMenuItem menuResetGrid;
        private ToolStripMenuItem menuCloseApplication;
        private Label label2;
        private Label label12;
        private Label label13;
        private HelpProvider helpProvider1;
        private bool startBtnPressed = false;
 
        public Form1()
        {
        //this will attempt to connect to the wii remote before using keyboard controls.
            try
            {
                wm = new Wiimote();
                wm.WiimoteChanged += wm_OnWiimoteChanged;
                wm.Connect();
            }
            catch (Exception e)
            {
            }
 
 
            InitializeComponent();
            soundEndGame.Load();
           // soundStartGame.Load();
            soundItemDropped.Load();
            soundMoveShape.Load();
            soundRotateShape.Load();
            SetUpGame();
            // setup the event to handle state changes
            // setup the event to handle insertion/removal of extensions
            //wm.WiimoteExtensionChanged += wm_OnWiimoteExtensionChanged;
            // connect to the Wiimote
 
            aBtnClicked = false;
            timer = new Timer();
            timer.Interval = 300;
            timer.Tick += new EventHandler(ClockTick);
            timer.Enabled = true;
 
            GameTimer.Enabled = true;
            GameTimer.Interval = gameSpeed;
 
        }
        void wm_OnWiimoteChanged(object sender, WiimoteChangedEventArgs args)
        {
            // current state information
            WiimoteState ws = args.WiimoteState;
            //move shape left.
            if (!isGameOver)
            {
 
                if (ws.ButtonState.Left == true && aShape.shapeMoving && !aBtnClicked)
                {
                    rectangleShape = aShape.moveShapeLeft(10, gameGrid.GetGameGrid());
                    aBtnClicked = true;
                    soundMoveShape.Play();
                }
                //move shape right.
                if (ws.ButtonState.Right == true && aShape.shapeMoving && !aBtnClicked)
                {
                    rectangleShape = aShape.moveShapeRight(10, gameGrid.GetGameGrid());
                    aBtnClicked = true;
                    soundMoveShape.Play();
                }
                //rotate shape right.
                if (ws.ButtonState.A == true && aShape.shapeMoving)
                {
                    rectangleShape = aShape.FlipShape("right", gameGrid.GetGameGrid());
                    soundRotateShape.Play();
                }
                //rotate shape left.
                if (ws.ButtonState.B == true && aShape.shapeMoving)
                {
                    rectangleShape = aShape.FlipShape("left", gameGrid.GetGameGrid());
                    soundRotateShape.Play();
                }
                /*
                //Pause the game.
                if (ws.ButtonState.Plus == true)
                {
                   if (!isGamePaused)
                        {
                            GameTimer.Stop();
                            isGamePaused = true;
                        }
                        else
                        {
                            GameTimer.Start();
                            isGamePaused = false;
                        }
                }
                 */
                //drop the shape quickly
                if (ws.ButtonState.Down == true && aShape.shapeMoving)
                {
                    dropBtnPressed = true;
                    // isDropped = true;
                }
            }
            if (isGameOver && ws.ButtonState.Home == true)
            {
                // create a shape to start with
                SetUpGame();
                startBtnPressed = true;
            }
            if (ws.ButtonState.Minus == true)
            {
                Application.Exit();
            }
        }
        void ClockTick(Object sender, EventArgs e)
        {
            aBtnClicked = false;
        }
 
        private void LayoutForm_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            string strKeyPress = null;
            strKeyPress = e.KeyCode.ToString();
            if (!isGameOver)
            {
                switch (strKeyPress.ToUpper())
                {
                    case "F":
                        if (aShape.shapeMoving) rectangleShape = aShape.moveShapeLeft(10, gameGrid.GetGameGrid());
                        soundMoveShape.Play();
                        break;
                    case "J":
                        if (aShape.shapeMoving) rectangleShape = aShape.moveShapeRight(10, gameGrid.GetGameGrid());
                        soundMoveShape.Play();
                        break;
                    case "H":
                        if (aShape.shapeMoving) rectangleShape = aShape.FlipShape("right", gameGrid.GetGameGrid());
                        soundRotateShape.Play();
                        break;
                    case "G":
                        if (aShape.shapeMoving) rectangleShape = aShape.FlipShape("left", gameGrid.GetGameGrid());
                        soundRotateShape.Play();
                        break;
                    case "Q":
                        GameTimer.Stop();
                        SetUpGame();
                        DrawStart();
                        break;
                    case "W":
                        Application.Exit();
                        break;
                    case "P":
                        if (!isGamePaused)
                        {
                            GameTimer.Stop();
                            isGamePaused = true;
                        }
                        else
                        {
                            GameTimer.Start();
                            isGamePaused = false;
                        }
                        break;
                    case "SPACE":
                        if (aShape.shapeMoving)
                        {
                            soundItemDropped.Load();
                            GameTimer.Interval = dropRate;
                            isDropped = true;
                        }
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (strKeyPress.ToUpper())
                {
                    case "S":
                        // create a shape to start with
                        SetUpGame();
                        shapeType = GetShapeType();
                        aShape = new Shape(shapeType, mainScreen.screenWidth, mainScreen.screenHeight, false);
                        nextShapeType = GetShapeType();
                        //  nextShape = new Shape(nextShapeType, theNextShape.screenWidth, theNextShape.screenHeight, true);
                        aShape.shapeMoving = true;
                        isGameOver = false;
                        GameTimer.Interval = gameSpeed;
                        GameTimer.Enabled = true;
                        GameTimer.Start();
                        break;
                    default:
                        break;
                }
            }
        }
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }
 
        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.lblScore = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRows = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.drawingAreaCanvas = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menuNewGame = new System.Windows.Forms.ToolStripMenuItem();
            this.menuResetGrid = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCloseApplication = new System.Windows.Forms.ToolStripMenuItem();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            //
            // GameTimer
            //
            this.GameTimer.Tick += new System.EventHandler(this.GameTimer_Tick);
            //
            // lblScore
            //
            this.lblScore.AutoSize = true;
            this.lblScore.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblScore.Location = new System.Drawing.Point(275, 25);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(13, 13);
            this.lblScore.TabIndex = 3;
            this.lblScore.Text = "0";
            //
            // label11
            //
            this.label11.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(8, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 11);
            this.label11.TabIndex = 1;
            this.label11.Text = "<P> - Pause/Un-pause";
            //
            // label10
            //
            this.label10.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(8, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 11);
            this.label10.TabIndex = 1;
            this.label10.Text = "<Q> - Reset the Grid";
            //
            // label8
            //
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(8, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 11);
            this.label8.TabIndex = 1;
            this.label8.Text = "<G> - Rotate Left";
            //
            // label9
            //
            this.label9.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(8, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 11);
            this.label9.TabIndex = 1;
            this.label9.Text = "<H> - Rotate Right";
            //
            // label4
            //
            this.label4.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(8, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "<SPACE> - Drop Shape";
            //
            // label5
            //
            this.label5.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(8, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "<S> - Start Game";
            //
            // label6
            //
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(8, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 11);
            this.label6.TabIndex = 1;
            this.label6.Text = "<F> - Move Left";
            //
            // label7
            //
            this.label7.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(8, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "<J> - Move Right";
            //
            // label1
            //
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(202, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Player Score";
            //
            // label3
            //
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(179, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Completed Rows:";
            //
            // lblRows
            //
            this.lblRows.AutoSize = true;
            this.lblRows.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblRows.Location = new System.Drawing.Point(275, 47);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(13, 13);
            this.lblRows.TabIndex = 6;
            this.lblRows.Text = "0";
            //
            // panel1
            //
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(188, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(120, 248);
            this.panel1.TabIndex = 7;
            //
            // label13
            //
            this.label13.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(8, 210);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 36);
            this.label13.TabIndex = 4;
            this.label13.Text = "to close the game press the minus button";
            //
            // label12
            //
            this.label12.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(8, 158);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 52);
            this.label12.TabIndex = 3;
            this.label12.Text = "Use the directional pad to move, A and B to rotate the shapes.";
            //
            // label2
            //
            this.label2.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(8, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "If you are using the Wiimote: Press Home to start";
            //
            // drawingAreaCanvas
            //
            this.drawingAreaCanvas.BackColor = System.Drawing.SystemColors.WindowText;
            this.drawingAreaCanvas.Location = new System.Drawing.Point(12, 38);
            this.drawingAreaCanvas.Name = "drawingAreaCanvas";
            this.drawingAreaCanvas.Size = new System.Drawing.Size(161, 286);
            this.drawingAreaCanvas.TabIndex = 0;
            //
            // menuStrip1
            //
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFile});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(320, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            //
            // menuFile
            //
            this.menuFile.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuNewGame,
            this.menuResetGrid,
            this.menuCloseApplication});
            this.menuFile.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.menuFile.Name = "menuFile";
            this.menuFile.Size = new System.Drawing.Size(37, 20);
            this.menuFile.Text = "File";
            //
            // menuNewGame
            //
            this.menuNewGame.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuNewGame.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.menuNewGame.Name = "menuNewGame";
            this.menuNewGame.Size = new System.Drawing.Size(132, 22);
            this.menuNewGame.Text = "New Game";
            this.menuNewGame.Click += new System.EventHandler(this.menuNewGame_Click);
            //
            // menuResetGrid
            //
            this.menuResetGrid.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuResetGrid.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.menuResetGrid.Name = "menuResetGrid";
            this.menuResetGrid.Size = new System.Drawing.Size(132, 22);
            this.menuResetGrid.Text = "Reset Grid";
            this.menuResetGrid.Click += new System.EventHandler(this.menuResetGrid_Click);
            //
            // menuCloseApplication
            //
            this.menuCloseApplication.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuCloseApplication.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.menuCloseApplication.Name = "menuCloseApplication";
            this.menuCloseApplication.Size = new System.Drawing.Size(132, 22);
            this.menuCloseApplication.Text = "Exit";
            this.menuCloseApplication.Click += new System.EventHandler(this.menuCloseApplication_Click);
            //
            // Form1
            //
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(320, 325);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblRows);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.drawingAreaCanvas);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tetris Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.LayoutForm_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LayoutForm_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
 
        }
        #endregion
 
        private void Form1_Load(object sender, System.EventArgs e)
        {
        }
        private void DrawScreen()
        {
            Graphics g = mainScreen.GetGraphics();
            gameGridBrushes = gameGrid.GetGameGridBrushes();
            theBrushColors = gameGrid.GetShapeColors();
            rectangleGameGrid = gameGrid.GetGameGrid();
            mainScreen.erase();
            // draw the stationary shapes first
            for (int i=0;i<numberOfRows;i++)
            {
                for (int k=0;k<numberOfCols;k++)
                {
                    if (!gameGrid.IsGridLocationEmpty(i,k))
                    {
                        g.FillRectangle(gameGridBrushes[i][k],rectangleGameGrid[i][k]);
                        g.DrawRectangle(new Pen(Color.White,1),rectangleGameGrid[i][k]);
                    }
                }
            }
            // now draw the moving shape
            for (int j=0;j<rectangleShape.Length;j++)
            {
                g.FillRectangle(theBrushColors[shapeType-1],rectangleShape[j]);
                g.DrawRectangle(new Pen(Color.White,1),rectangleShape[j]);
            }
 
 
            mainScreen.flip();
            bonusStep--;
 
 
        }
        private void LayoutForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            DrawStart();
        }
 
 
        private void GameTimer_Tick(object sender, System.EventArgs e)
        {
            if (aBtnClicked)
            {
            }
            if (startBtnPressed)
            {
                SetUpGame();
 
               // soundGameStart.Play();
 
                shapeType = GetShapeType();
                aShape = new Shape(shapeType, mainScreen.screenWidth, mainScreen.screenHeight, false);
                nextShapeType = GetShapeType();
                //  nextShape = new Shape(nextShapeType, theNextShape.screenWidth, theNextShape.screenHeight, true);
                aShape.shapeMoving = true;
                isGameOver = false;
                GameTimer.Interval = gameSpeed;
                GameTimer.Enabled = true;
                GameTimer.Start();
                startBtnPressed = false;
                return;
            }
            if (aShape != null)
            {
                if (aShape.shapeMoving)
                {
                    if (dropBtnPressed)
                    {
                        GameTimer.Interval = dropRate;
                        dropBtnPressed = false;
                        soundItemDropped.Play();
                    }
                    rectangleShape = aShape.moveShapeDown(dropRate, gameGrid.GetGameGrid());
                    DrawScreen();
 
                }
 
                else
                {
                    int XCoordinate;
                    int YCoordinate;
                    // the current shape has stopped moving
                    // is the shape within the game area? If not, then the game is over
                    for (int i = 0; i < 4; i++)
                    {
                        if (!rectangle.Contains(rectangleShape[i]))
                        {
                            isGameOver = true;
                            break;
                        }
                    }
                    if (!isGameOver)
                    {
                        int[] intYCoordinates = new int[4];
                        // paint the shape's final position
                        for (int i = 0; i < 4; i++)
                        {
                            XCoordinate = rectangleShape[i].X;
                            YCoordinate = rectangleShape[i].Y;
                            intYCoordinates[i] = YCoordinate / 10;
                            // copy the shape's position into the game grid array
                            gameGrid.SetShapeLocation(YCoordinate / 10, XCoordinate / 10, rectangleShape[i], shapeType);
                        }
                        // this sorts the array of our Y coordinates so that we go from small to large
                        // this enures that we drop rwos sequentially
                        Array.Sort(intYCoordinates);
                        for (int i = 0; i < 4; i++)
                        {
                            isRowFull = true;
                            // check to see if the shape causes an entire row to fill
                            // if it does then we need to eliminate the row and drop the rest down
                            for (int j = 0; j < numberOfCols; j++)
                            {
                                if (gameGrid.IsGridLocationEmpty(intYCoordinates[i], j))
                                {
                                    isRowFull = false;
                                    break;
                                    soundItemDropped.Play();
                                }
                            }
                            if (isRowFull)
                            {
                                // drop the row and fill from the next row down
                                for (int k = intYCoordinates[i]; k > 0; k--)
                                {
                                    // need to update all the coordinates of our shapes
                                    for (int l = 0; l < numberOfCols; l++)
                                    {
                                        // set the value into the row below
                                        gameGrid.DropRowsDown(k, l);
                                    }
                                }
                                // need to do row 0
                                gameGrid.SetTopRow();
                                // update the score
                                UpdateScore(intYCoordinates[i]);
                                bonusHeight = drawingAreaCanvas.Height - 1;
                                bonusStep = 5;
                            }
                        }
                        shapeType = nextShapeType;
                        aShape = new Shape(shapeType, mainScreen.screenWidth, mainScreen.screenHeight, false);
                        nextShapeType = GetShapeType();
                        //nextShape = new Shape(nextShapeType, nextShapeScreen.screenWidth, nextShapeScreen.screenHeight, true);
                        aShape.shapeMoving = true;
                        // reset the game speed
                        GameTimer.Interval = gameSpeed;
                        isDropped = false;
                    }
                    else
                    {
                        GameTimer.Stop();
                        //    SetUpGame();
                        DrawGameOver();
                        soundEndGame.Play();
                    }
                }
            }
        }
 
 
        private void DrawStart()
        {
            Graphics gStart = startScreen.GetGraphics();
            startScreen.erase();
 
 
            startScreen.flip();
        }
        private void UpdateScore(int intRowNum)
        {
            levelRowsCompleted++;
            totalRowsCompleted++;
            int reverseRow = 30 - intRowNum;
            score = score + (reverseRow * levelRowsCompleted * level * 10) + (bonusHeight * (level * levelRowsCompleted));
            lblScore.Text = score.ToString();
            if (levelRowsCompleted == 10)
            {
                UpdateLevel();
                levelRowsCompleted = 0;
            }
            lblRows.Text = totalRowsCompleted.ToString();
        }
        private void UpdateLevel()
        {
            level++;
            if (gameSpeed > 10) gameSpeed -= 10;
        }
        private void SetUpGame()
        {
            // set initial variable values
            gameSpeed = 100;
            bonusHeight = drawingAreaCanvas.Height-1;
            dropRate = 5;
            bonusStep = 5;
            score = 0;
            level = 1;
            levelRowsCompleted = 0;
            totalRowsCompleted = 0;
            isGameOver = true;
            isDropped = false;
 
            lblScore.Text = score.ToString();
            lblRows.Text = totalRowsCompleted.ToString();
 
            // create our main window
            rectangle = new Rectangle(0,0,drawingAreaCanvas.Width, drawingAreaCanvas.Height);
            drawingAreaWidth = rectangle.Width;
            drawingAreaHeight = rectangle.Height;
            mainScreen = new Screen(drawingAreaCanvas, rectangle);
            // create our start screen
            rectangle = new Rectangle(0,0,drawingAreaCanvas.Width, drawingAreaCanvas.Height);
            startScreen = new Screen(drawingAreaCanvas, rectangle);
 
            // create the GameGrid
            numberOfRows = (drawingAreaCanvas.Height-1)/10;
            numberOfCols = (drawingAreaCanvas.Width-1)/10;
            gameGrid = new GameGrid(numberOfRows, numberOfCols);
 
        }
        private void DrawGameOver()
        {
            Graphics gOver = startScreen.GetGraphics();
            startScreen.erase();
            gOver.DrawString("GAME OVER",new Font("Courier",18),new SolidBrush(Color.Red),5,100);
            startScreen.flip();
        }
 
        private int GetShapeType()
        {
            int shapeType;
            do
            {
                shapeType = randomShapeType.Next(6);
            }while (shapeType == 0);
            return shapeType;
        }
 
        private void menuNewGame_Click(object sender, EventArgs e)
        {
            // create a shape to start with
            SetUpGame();
            shapeType = GetShapeType();
            aShape = new Shape(shapeType, mainScreen.screenWidth, mainScreen.screenHeight, false);
            nextShapeType = GetShapeType();
            //  nextShape = new Shape(nextShapeType, theNextShape.screenWidth, theNextShape.screenHeight, true);
            aShape.shapeMoving = true;
            isGameOver = false;
            GameTimer.Interval = gameSpeed;
            GameTimer.Enabled = true;
            GameTimer.Start();
        }
 
        private void menuResetGrid_Click(object sender, EventArgs e)
        {
            GameTimer.Stop();
            SetUpGame();
            DrawStart();
        }
 
        private void menuCloseApplication_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
 
        private void rulesToolStripMenuItem_Click(object sender, EventArgs e)
        {//this was the menu item that would have displayed the rules.
           //open the readme.txt file for player to read.
           // FileInfo f = new FileInfo("readme.txt");
           //FileStream s = f.Open(FileMode.OpenOrCreate, FileAccess.Read);
            //the following comes from: http://www.codeguru.com/csharp/csharp/cs_syntax/anandctutorials/article.php/c5861#more
            Console.WriteLine("Reading the contents from the file");
            StreamReader s = File.OpenText(@"readme.txt");
            string read = null;
            while ((read = s.ReadLine()) != null)
            {
                Console.WriteLine(read);
            }
            s.Close();
 
 
        }
    }
}